# Todolist

feel free to contribute <3 ([CONTRIBUTING.md](CONTRIBUTING.md))

- [ ] ${config.users.users.${user}.home} instead of "/home/${username}"
- [ ] Hyprpanel screenshot
- [ ] PIA Vpn (issue in progress)
- [ ] Webcord (system24 theme? Tui)
- [ ] check gvolpe/nix-config
- [ ] <https://github.com/isabelroses/dotfiles/blob/main/home/comfy/system/xdg.nix>
